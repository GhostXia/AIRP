(function () {
  'use strict';

  const $ = selector => document.querySelector(selector);
  const screen = document.body.dataset.screen || 'diagnostics';
  const params = new URLSearchParams(location.search);
  const requestedEngine = params.get('engine');
  if (requestedEngine && /^https?:\/\//i.test(requestedEngine)) sessionStorage.setItem('airp_engine_url', requestedEngine.replace(/\/+$/, ''));
  const connection = {
    base: sessionStorage.getItem('airp_engine_url') || location.origin,
    // C-P2：函数形态 bearer——每次请求时解析当前 sessionStorage 值，
    // token 续期（rotation）后新值即刻生效，无需重建 client。
    bearer: () => sessionStorage.getItem('airp_bearer') || '',
  };
  // C-P1：8h bearer 生命周期的失败可见化。桌面壳注入的 desktop session token
  // 过期后，API 会返回 401；这里把首次 401 变成用户可见的状态栏提示。
  // C-P2：401 先尝试 desktop-session 续期（rotation）；无 key 模式 renew
  // 端点 403 fail-closed → 钩子返回 false → 行为回退到本可见化提示。
  let authExpired = false;
  function markAuthExpired() {
    if (authExpired) return;
    authExpired = true;
    const target = $('#runtime-status');
    if (target) {
      target.textContent = '鉴权失效（401）：会话 token 已过期或无效，请重启应用或重新保存连接';
      target.classList.add('error');
    }
  }
  function resetAuthExpired() {
    if (!authExpired) return;
    authExpired = false;
    const target = $('#runtime-status');
    if (target) {
      target.textContent = '';
      target.classList.remove('error');
    }
  }
  const client = AIRPApi.createClient({
    base: connection.base,
    bearer: connection.bearer,
    onRequest: info => { if (info && info.status === 401) markAuthExpired(); },
    onUnauthorized: async () => {
      // #485 W3：AIRPDesktopSession 仅桌面壳（entry.js）注入；local-webui
      // 便携模式下全局不存在，直接引用会 ReferenceError 击穿 401 恢复
      // 链。先 typeof 守卫，非桌面环境无续期可用，返回 false 走常规失败面。
      if (typeof AIRPDesktopSession === 'undefined') return false;
      const renewed = await AIRPDesktopSession.renewDesktopSession({ base: connection.base });
      if (renewed) resetAuthExpired();
      return renewed;
    },
  });
  const state = {
    characterId: params.get('character') || sessionStorage.getItem('airp_character_id') || '',
    sessionId: params.get('session') || sessionStorage.getItem('airp_session_id') || '',
    userId: sessionStorage.getItem('airp_user_id') || 'default',
    characters: [],
    sessions: [],
    // E-P1-5：保存最近一次 worldbook/preset 导入诊断，供重新渲染时复显。
    lastLorebookReport: null,
    lastPresetReport: null,
  };

  const pages = [
    ['03', 'workbench', '角色工作台', '03-workbench.html'],
    ['04', 'worldbook', '世界书', '04-world-book.html'],
    ['05', 'presets', '预设', '05-presets.html'],
    ['06', 'persona', 'Persona', '06-user-persona.html'],
    ['07', 'agent', 'Agent 运行', '07-agent-runs.html'],
    ['08', 'settings', '设置', '08-settings.html'],
    ['17', 'memory', '记忆与状态', '17-memory-state.html'],
    ['18', 'scenes', '多人场景', '18-group-chat.html'],
    ['19', 'branches', '分支与 Swipe', '19-branch-tree.html'],
    ['20', 'preview', '装配预览', '20-assembly-preview.html'],
    ['21', 'quota', '用量配额', '21-usage-quota.html'],
    ['23', 'diagnostics', '诊断', '23-diagnostics.html'],
    ['32', 'style', '风格系统', '32-style-review.html'],
    ['34', 'graph', '关系图谱', '34-relationship-graph.html'],
    ['35', 'plotarc', '剧情弧', '35-plot-arc.html'],
    ['36', 'imagegen', '图片生成', '36-image-gen.html'],
    ['37', 'templates', '模板库', '37-character-templates.html'],
    ['38', 'stylelearn', '风格迁移', '38-style-learn.html'],
    ['39', 'dialoguegen', '对话示例', '39-dialogue-gen.html'],
    ['40', 'wbgraph', '知识图谱', '40-worldbook-graph.html'],
    ['41', 'timeline', '时间线导出', '41-timeline-export.html'],
    ['42', 'carddiff', '版本对比', '42-card-diff.html'],
    ['43', 'providers', '多 Provider 路由', '43-provider-management.html'],
    ['44', 'plugintools', '插件工具', '44-plugin-tools.html'],
  ];
  const titles = Object.fromEntries(pages.map(item => [item[1], item[2]]));

  function node(tag, className, text) {
    const value = document.createElement(tag);
    if (className) value.className = className;
    if (text !== undefined) value.textContent = text;
    return value;
  }
  function button(text, action, kind) {
    const value = node('button', 'btn ' + (kind || 'btn-secondary'), text);
    value.type = 'button';
    if (action) value.addEventListener('click', action);
    return value;
  }
  function input(label, value, options) {
    const wrap = node('label', 'field');
    wrap.appendChild(node('span', 'field-label', label));
    const control = document.createElement(options && options.multiline ? 'textarea' : options && options.select ? 'select' : 'input');
    control.className = options && options.multiline ? 'textarea runtime-textarea' + (options.code ? ' code' : '') : options && options.select ? 'select runtime-select' : 'input runtime-input';
    if (options && options.type && !options.select) control.type = options.type;
    if (options && options.placeholder) control.placeholder = options.placeholder;
    if (options && options.select) {
      for (const item of options.select) {
        const option = node('option', '', item.label == null ? item.value : item.label);
        option.value = item.value;
        control.appendChild(option);
      }
    }
    control.value = value == null ? '' : String(value);
    wrap.appendChild(control);
    return { wrap, control };
  }
  function card(title, full) {
    const value = node('section', 'runtime-card' + (full ? ' full' : ''));
    value.appendChild(node('h2', '', title));
    return value;
  }
  function output(value, tall) {
    const pre = node('pre', 'runtime-output' + (tall ? ' tall' : ''));
    pre.textContent = value || '';
    return pre;
  }
  function actions() { return node('div', 'runtime-actions'); }
  function json(value) { return JSON.stringify(value, null, 2); }
  function parseJson(text, label) {
    try { return JSON.parse(text); } catch (error) { throw new Error((label || 'JSON') + ' 格式错误：' + error.message); }
  }
  // E-P1-5：渲染 worldbook/preset 导入诊断面板，暴露 advisory 字段与 needs_review/invalid 条目。
  // 后端 normalize_worldbook / normalize_preset 已在 PUT/POST 响应中返回 import_report；
  // 此 helper 把 report 翻译成可见 DOM，避免 advisory 字段被静默降级。
  function renderImportReport(report, kind) {
    if (!report || typeof report !== 'object') return null;
    const panel = node('div', 'import-report');
    const head = node('div', 'import-report-head');
    const titleText = kind === 'preset' ? 'Preset 导入诊断' : '世界书导入诊断';
    head.appendChild(node('span', 'import-report-title', titleText));
    const hasIssues = report.source_error || (Array.isArray(report.invalid) && report.invalid.length) || (Array.isArray(report.needs_review) && report.needs_review.length);
    head.appendChild(node('span', hasIssues ? 'import-report-tag warn' : 'import-report-tag ok', hasIssues ? '需关注' : '正常'));
    panel.appendChild(head);
    // 概览计数行
    const overview = node('div', 'import-report-overview');
    const stats = [
      '输入 ' + (report.total_input ?? 0),
      '转换 ' + (report.converted ?? 0),
      '别名归一 ' + (report.aliases_normalized ?? 0),
      'advisory 保留 ' + (report.advisory_preserved ?? 0),
      '无效 ' + (Array.isArray(report.invalid) ? report.invalid.length : 0),
      '需复核 ' + (Array.isArray(report.needs_review) ? report.needs_review.length : 0),
    ];
    overview.textContent = stats.join(' · ');
    panel.appendChild(overview);
    // advisory 提示：明确标注运行时不消费
    if ((report.advisory_preserved ?? 0) > 0) {
      panel.appendChild(node('p', 'import-report-note', 'advisory 字段（如 position/probability/injection_position）已保留在 extensions/raw sidecar，但运行时不消费——仅 canonical 字段参与触发与装配。'));
    }
    // preset 专有元数据
    if (kind === 'preset' && (report.format_version || report.source_hash || report.converter_version)) {
      const meta = node('div', 'import-report-meta');
      const parts = [];
      if (report.format_version) parts.push('格式 ' + report.format_version);
      if (report.source_hash) parts.push('源 hash ' + report.source_hash);
      if (report.converter_version) parts.push('转换器 ' + report.converter_version);
      meta.textContent = parts.join(' · ');
      panel.appendChild(meta);
    }
    // source_error
    if (report.source_error) {
      panel.appendChild(node('p', 'import-report-error', '源错误：' + report.source_error));
    }
    // invalid 详情
    if (Array.isArray(report.invalid) && report.invalid.length) {
      panel.appendChild(node('div', 'import-report-section-title', '无效条目（已跳过）'));
      const ul = node('ul', 'import-report-list');
      for (const item of report.invalid) {
        const label = item.comment || item.name || item.identifier || ('#' + (item.index ?? '?'));
        ul.appendChild(node('li', 'import-report-item invalid', '[' + (item.index ?? '?') + '] ' + label + ' — ' + (item.reason || '')));
      }
      panel.appendChild(ul);
    }
    // needs_review 详情
    if (Array.isArray(report.needs_review) && report.needs_review.length) {
      panel.appendChild(node('div', 'import-report-section-title', '需人工复核（已写入但不触发）'));
      const ul = node('ul', 'import-report-list');
      for (const item of report.needs_review) {
        const label = item.comment || item.name || item.identifier || ('#' + (item.index ?? '?'));
        ul.appendChild(node('li', 'import-report-item review', '[' + (item.index ?? '?') + '] ' + label + ' — ' + (item.reason || '')));
      }
      panel.appendChild(ul);
    }
    return panel;
  }
  function message(error) { return AIRPApi.errorMessage(error && error.data, error && error.message || String(error)); }
  function setStatus(text, error) {
    const target = $('#runtime-status');
    target.textContent = text;
    target.classList.toggle('error', Boolean(error));
  }
  async function task(label, operation) {
    setStatus(label + '…');
    try {
      const result = await operation();
      setStatus(label + '完成');
      return result;
    } catch (error) {
      setStatus(label + '失败：' + message(error), true);
      throw error;
    }
  }
  function pathWithState(path) {
    const url = new URL(path, location.href);
    if (state.characterId) url.searchParams.set('character', state.characterId);
    if (state.sessionId) url.searchParams.set('session', state.sessionId);
    if (client.base !== location.origin) url.searchParams.set('engine', client.base);
    return url.href;
  }
  function renderChrome() {
    $('#page-title').textContent = titles[screen] || 'AIRP 控制台';
    document.title = (titles[screen] || 'AIRP 控制台') + ' · AIRP';
    $('#engine-address').textContent = client.base === location.origin ? '同源 Engine' : client.base;
    const nav = $('#console-nav');
    nav.appendChild(node('div', 'nav-group', '工作区'));
    const home = node('a', 'nav-link', '角色与会话'); home.href = pathWithState('01-role-list.html'); nav.appendChild(home);
    for (const [index, id, title, href] of pages) {
      const link = node('a', 'nav-link' + (id === screen ? ' active' : ''));
      link.href = pathWithState(href);
      link.append(node('span', 'nav-index', index), node('span', '', title));
      nav.appendChild(link);
    }
    const related = $('#related-links');
    for (const [label, href] of [['对话空间', '02-chat-space.html'], ['角色列表', '01-role-list.html'], ['设置', '08-settings.html'], ['诊断', '23-diagnostics.html']]) {
      const link = node('a', 'context-link', label + ' →'); link.href = pathWithState(href); related.appendChild(link);
    }
  }
  async function loadScope() {
    state.characters = await client.request('GET', '/v1/characters').catch(() => []);
    if (!state.characters.includes(state.characterId)) state.characterId = state.characters[0] || '';
    if (state.characterId) {
      sessionStorage.setItem('airp_character_id', state.characterId);
      state.sessions = await client.request('GET', '/v1/sessions/' + encodeURIComponent(state.characterId)).catch(() => []);
      if (!state.sessions.includes(state.sessionId)) state.sessionId = state.sessions[0] || '';
      if (state.sessionId) sessionStorage.setItem('airp_session_id', state.sessionId);
    }
    $('#scope-character').textContent = state.characterId || '未选择';
    $('#scope-session').textContent = state.sessionId || '未选择';
    $('#scope-user').textContent = state.userId;
  }
  function selector(label, values, current, changed) {
    const choices = values.map(value => ({ value: String(value), label: String(value) }));
    if (!choices.length) choices.push({ value: '', label: '无可用项' });
    const field = input(label, current, { select: choices });
    field.control.addEventListener('change', () => changed(field.control.value));
    return field;
  }
  function characterSelector(reload) {
    return selector('角色', state.characters, state.characterId, value => {
      state.characterId = value; state.sessionId = ''; sessionStorage.setItem('airp_character_id', value); reload();
    });
  }
  function sessionSelector(reload) {
    return selector('会话', state.sessions, state.sessionId, value => {
      state.sessionId = value; sessionStorage.setItem('airp_session_id', value); reload();
    });
  }

  function connectionCard() {
    const box = card('浏览器到 Engine 的连接', true); const form = node('div', 'runtime-form'); box.appendChild(form);
    const address = input('Engine 地址', connection.base, { placeholder: location.origin });
    const bearer = input('Bearer Token（只保存在当前标签会话）', '', { type: 'password' });
    form.append(address.wrap, bearer.wrap, node('p', 'runtime-muted', '同源便携版不需要填写。远程开发联调时可在这里设置 Engine 地址与访问密钥；页面不会把密钥写入 URL 或持久化存储。'), button('保存连接并重新加载', () => {
      const next = address.control.value.trim().replace(/\/+$/, '');
      if (!/^https?:\/\//i.test(next)) { setStatus('Engine 地址必须是完整的 http(s) URL', true); return; }
      sessionStorage.setItem('airp_engine_url', next);
      if (bearer.control.value) sessionStorage.setItem('airp_bearer', bearer.control.value); else sessionStorage.removeItem('airp_bearer');
      location.reload();
    }, 'btn-primary'));
    return box;
  }

  async function renderWorkbench() {
    const view = $('#view'); view.replaceChildren();
    const info = card('角色卡编辑', true); const form = node('div', 'runtime-form'); info.appendChild(form); view.appendChild(info);
    form.appendChild(characterSelector(renderWorkbench).wrap);
    if (!state.characterId) { form.appendChild(node('p', 'runtime-muted', '请先导入角色卡。')); return; }
    const source = await task('读取角色卡', () => client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId)));
    const bar = actions();
    bar.append(button('保存 JSON', async () => {
      await task('保存角色卡', () => client.request('PUT', '/v1/characters/' + encodeURIComponent(state.characterId), parseJson(editor.control.value, '角色卡')));
    }, 'btn-primary'));
    const reextractButton = button('重新提取附属资源', () => {
      AIRPWorkbench.reextractCharacterResources({
        characterId: state.characterId,
        button: reextractButton,
        confirm: text => AIRPConfirm.confirm(text, { title: '确认重新提取附属资源' }),
        request: (...args) => client.request(...args),
        setStatus,
        errorMessage: message,
      });
    });
    bar.append(reextractButton);
    // Phase 1.6: Decompose / Analysis 入口
    bar.append(button('拆解角色卡', async () => {
      const result = await task('拆解角色卡', () => client.request('POST', '/v1/characters/' + encodeURIComponent(state.characterId) + '/decompose'));
      setStatus('拆解完成：' + (result.files_written || []).length + ' 个文件已写入 analysis/');
      renderAnalysisPanel(form);
    }));
    bar.append(button('查看 Analysis', async () => {
      renderAnalysisPanel(form);
    }));
    bar.append(button('发送到对话', () => { location.href = pathWithState('02-chat-space.html'); }));
    form.appendChild(bar);
    // NL enhance 区（规划中 · 契约未交付）
    const nlZone = node('div', 'nl-zone');
    const nlHead = node('div', 'nl-head');
    nlHead.append(node('span', 'nl-title', '自然语言指导 Agent 修改'), node('span', 'nl-planned-tag', '规划中 · 契约未交付'));
    nlZone.appendChild(nlHead);
    const nlInputRow = node('div', 'nl-input-row');
    const nlGenBtn = button('生成改写', null, 'btn-primary'); nlGenBtn.disabled = true;
    nlInputRow.append(node('div', 'nl-input', '用自然语言描述想怎么改，例如：把艾拉的性格改得更谨慎'), nlGenBtn);
    nlZone.append(nlInputRow, node('p', 'nl-note', '后端契约未交付时此区不可操作；不影响手动编辑与 JSON 保存。'));
    form.appendChild(nlZone);
    // JSON 高级折叠区
    const ja = node('div', 'json-advanced');
    const jaBar = node('div', 'ja-bar'); jaBar.append(node('span', 'ja-arrow', '▾'), node('span', 'ja-title', '高级：JSON 整体替换'), node('span', 'ja-state', '默认折叠 · 点击展开'));
    jaBar.addEventListener('click', () => { jaBody.style.display = jaBody.style.display === 'none' ? '' : 'none'; jaArrow.textContent = jaBody.style.display === 'none' ? '▸' : '▾'; });
    const jaArrow = jaBar.querySelector('.ja-arrow');
    const jaBody = node('div', 'ja-body'); jaBody.style.display = 'none';
    jaBody.append(node('div', 'ja-warn', '⚠ 保存会整体替换当前角色卡（rev ' + (source.revision || '?') + '）——结构化表单中的未保存修改将被覆盖。'));
    const editor = input('角色卡 JSON（整体替换）', json(source), { multiline: true, code: true });
    jaBody.append(editor.wrap, node('div', 'ja-actions', button('保存 JSON（整体替换）', async () => {
      await task('保存角色卡', () => client.request('PUT', '/v1/characters/' + encodeURIComponent(state.characterId), parseJson(editor.control.value, '角色卡')));
    }, 'btn-secondary')));
    ja.append(jaBar, jaBody);
    form.appendChild(ja);

    // Phase 1.6: Analysis 面板（动态加载）
    async function renderAnalysisPanel(container) {
      const old = container.querySelector('.analysis-panel'); if (old) old.remove();
      const panel = node('div', 'analysis-panel runtime-form');
      panel.appendChild(node('h3', '', 'Analysis 拆解产物'));
      try {
        const list = await task('读取 Analysis 列表', () => client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/analysis'));
        const files = list.files || [];
        if (!files.length) { panel.appendChild(node('p', 'runtime-muted', '还没有拆解产物。点击“拆解角色卡”生成。')); }
        else {
          const fileList = node('div', 'runtime-list');
          // B1 修复：AnalysisFileEntry 是 {filename, size} 对象，不能当字符串处理
          files.forEach(entry => {
            const filename = entry && typeof entry === 'object' ? entry.filename : entry;
            if (!filename) return;
            const sizeLabel = entry && typeof entry === 'object' && typeof entry.size === 'number' ? ' · ' + entry.size + ' B' : '';
            const row = node('div', 'runtime-row');
            row.appendChild(node('div', 'runtime-row-title', filename + sizeLabel));
            const ops = node('div', 'op-col');
            const viewBtn = node('span', 'op-link', '查看');
            viewBtn.style.cursor = 'pointer';
            viewBtn.addEventListener('click', async () => {
              const file = await task('读取 ' + filename, () => client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/analysis/' + encodeURIComponent(filename)));
              const oldContent = panel.querySelector('.analysis-content'); if (oldContent) oldContent.remove();
              const oldApply = panel.querySelector('.analysis-apply'); if (oldApply) oldApply.remove();
              const pre = output(file.content || '', true); pre.classList.add('analysis-content');
              panel.appendChild(pre);
            });
            const enhanceBtn = node('span', 'op-link', 'Enhance');
            enhanceBtn.style.cursor = 'pointer';
            enhanceBtn.addEventListener('click', async () => {
              const result = await task('Enhance ' + filename, () => client.request('POST', '/v1/characters/' + encodeURIComponent(state.characterId) + '/analysis/' + encodeURIComponent(filename), { action: 'enhance' }));
              const oldContent = panel.querySelector('.analysis-content'); if (oldContent) oldContent.remove();
              const oldApply = panel.querySelector('.analysis-apply'); if (oldApply) oldApply.remove();
              const pre = output(result.enhanced_md || result.diff || json(result), true); pre.classList.add('analysis-content');
              panel.appendChild(pre);
              if (result.enhanced_md) {
                const applyBtn = button('应用 Enhance 结果到 ' + filename, async () => {
                  await task('Apply ' + filename, () => client.request('POST', '/v1/characters/' + encodeURIComponent(state.characterId) + '/analysis/' + encodeURIComponent(filename), { action: 'apply', enhanced_md: result.enhanced_md }));
                  setStatus(filename + ' 已应用增强结果');
                }, 'btn-primary');
                applyBtn.classList.add('analysis-apply');
                panel.appendChild(applyBtn);
              }
            });
            ops.append(viewBtn, enhanceBtn);
            row.appendChild(ops);
            fileList.appendChild(row);
          });
          panel.appendChild(fileList);
        }
      } catch (error) { panel.appendChild(node('p', 'runtime-muted', '加载失败：' + message(error))); }
      container.appendChild(panel);
    }
  }

  async function renderWorldbook() {
    const view = $('#view'); view.replaceChildren(); const box = card('角色世界书', true); const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box);
    form.appendChild(characterSelector(renderWorldbook).wrap);
    // E-P1-5：复显最近一次世界书导入诊断（advisory/invalid/needs_review）
    if (state.lastLorebookReport) {
      const reportPanel = renderImportReport(state.lastLorebookReport, 'worldbook');
      if (reportPanel) form.appendChild(reportPanel);
    }
    if (!state.characterId) { form.appendChild(node('p', 'runtime-muted', '没有可读取的角色。')); return; }
    let book = {};
    try { book = await client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/lorebook'); }
    catch (error) { if (error.status !== 404) throw error; setStatus('该角色尚无世界书；保存后创建'); }
    // 条目级操作列
    const entries = book.entries || [];
    // E-P1-5：saveBookRaw 捕获 PUT 响应中的 import_report，存入 state 供重新渲染复显。
    const saveBookRaw = async (body, countFallback) => {
      const resp = await task('保存世界书', () => client.request('PUT', '/v1/characters/' + encodeURIComponent(state.characterId) + '/lorebook', body));
      state.lastLorebookReport = (resp && resp.import_report) ? resp.import_report : null;
      const count = resp && resp.entries_count != null ? resp.entries_count : countFallback;
      const diagSuffix = resp && resp.import_report ? ' · 诊断已显示' : '';
      setStatus('世界书已保存（' + count + ' 条' + diagSuffix + '）');
      renderWorldbook();
    };
    const saveBook = (newEntries) => saveBookRaw(Object.assign({}, book, { entries: newEntries }), newEntries.length);
    if (entries.length) {
      const list = node('div', 'runtime-list');
      entries.forEach((entry, idx) => {
        const row = node('div', 'runtime-row');
        const main = node('div', 'runtime-row-main');
        const keys = Array.isArray(entry.keys) ? entry.keys.join(', ') : entry.keys || '—';
        const content = String(entry.content || '').slice(0, 120);
        main.append(node('div', 'runtime-row-title', keys), node('div', 'runtime-row-meta', content + (entry.constant ? ' · constant' : entry.selective ? ' · selective' : '')));
        const ops = node('div', 'op-col');
        const sw = node('span', entry.enabled !== false ? 'switch on' : 'switch');
        sw.style.cursor = 'pointer';
        sw.addEventListener('click', async () => { entries[idx].enabled = entry.enabled === false; await saveBook(entries); });
        const editBtn = node('span', 'op-link', '编辑');
        editBtn.style.cursor = 'pointer';
        editBtn.addEventListener('click', () => {
          const old = list.querySelector('.entry-editor'); if (old) old.remove();
          const ed = node('div', 'entry-editor runtime-form');
          const keysInput = input('关键词（逗号分隔）', Array.isArray(entry.keys) ? entry.keys.join(', ') : entry.keys || '');
          const contentInput = input('内容', entry.content || '', { multiline: true, code: true });
          const saveBtn2 = button('保存条目', async () => {
            entries[idx].keys = keysInput.control.value.split(',').map(s => s.trim()).filter(Boolean);
            entries[idx].content = contentInput.control.value;
            await saveBook(entries);
          }, 'btn-primary');
          const cancelBtn = button('取消', () => ed.remove());
          ed.append(keysInput.wrap, contentInput.wrap, saveBtn2, cancelBtn);
          row.after(ed);
        });
        const delBtn = node('span', 'op-link del', '删除');
        delBtn.style.cursor = 'pointer';
        delBtn.addEventListener('click', async () => {
          if (!await AIRPConfirm.confirm('删除条目“' + keys + '”？', { title: '确认删除世界书条目' })) return;
          entries.splice(idx, 1); await saveBook(entries);
        });
        ops.append(editBtn, sw, delBtn);
        row.append(main, ops);
        list.appendChild(row);
      });
      form.appendChild(list);
    }
    // NL enhance 区（规划中 · 契约未交付）
    const nlZone = node('div', 'nl-zone');
    const nlHead = node('div', 'nl-head');
    nlHead.append(node('span', 'nl-title', '自然语言指导 Agent 修改（整本书级）'), node('span', 'nl-planned-tag', '规划中 · 契约未交付'));
    nlZone.append(nlHead);
    const nlInputRow = node('div', 'nl-input-row');
    const nlGenBtn2 = button('生成改写', null, 'btn-primary'); nlGenBtn2.disabled = true;
    nlInputRow.append(node('div', 'nl-input', '用自然语言描述想怎么改，例如：把废弃航道的危险等级上调'), nlGenBtn2);
    nlZone.append(nlInputRow, node('p', 'nl-note', '未确认前不会落盘 · 单条目级修改 v1 范围外'));
    form.appendChild(nlZone);
    // JSON 高级折叠区
    const ja = node('div', 'json-advanced');
    const jaBar = node('div', 'ja-bar');
    const jaArrow = node('span', 'ja-arrow', '▾');
    jaBar.append(jaArrow, node('span', 'ja-title', '高级：JSON 整体替换'), node('span', 'ja-state', '默认折叠 · 点击展开'));
    jaBar.addEventListener('click', () => { jaBody.style.display = jaBody.style.display === 'none' ? '' : 'none'; jaArrow.textContent = jaBody.style.display === 'none' ? '▸' : '▾'; });
    const jaBody = node('div', 'ja-body'); jaBody.style.display = 'none';
    jaBody.append(node('div', 'ja-warn', '⚠ 保存会整体替换世界书全部条目——按条编辑中的未保存修改将被覆盖。'));
    const editor = input('规范化世界书 JSON', json(book), { multiline: true, code: true });
    jaBody.append(editor.wrap, node('div', 'ja-actions', button('保存 JSON（整体替换）', () => saveBookRaw(parseJson(editor.control.value, '世界书'), (parseJson(editor.control.value, '世界书').entries || []).length), 'btn-secondary')));
    ja.append(jaBar, jaBody);
    form.appendChild(ja);
  }

  async function renderPresets() {
    const view = $('#view'); view.replaceChildren();
    const presets = await client.request('GET', '/v1/presets');
    const box = card('预设', false); const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box);
    // E-P1-5：复显最近一次 preset 导入诊断（advisory/invalid/needs_review）
    if (state.lastPresetReport) {
      const reportPanel = renderImportReport(state.lastPresetReport, 'preset');
      if (reportPanel) form.appendChild(reportPanel);
    }
    const pick = selector('已导入预设', presets, presets[0] || '', async value => { editor.control.value = json(await task('读取预设', () => client.request('GET', '/v1/presets/' + encodeURIComponent(value)))); }); form.appendChild(pick.wrap);
    const editor = input('Prompt 列表', presets.length ? json(await client.request('GET', '/v1/presets/' + encodeURIComponent(presets[0]))) : '[]', { multiline: true, code: true }); form.appendChild(editor.wrap);
    const importer = card('导入新预设', true); const importForm = node('div', 'runtime-form'); importer.appendChild(importForm); view.appendChild(importer);
    const id = input('Preset ID', '', { placeholder: '例如 concise-rp' }); const raw = input('TavernPreset JSON', '', { multiline: true, code: true }); importForm.append(id.wrap, raw.wrap);
    importForm.appendChild(button('校验并导入', async () => {
      parseJson(raw.control.value, '预设');
      const result = await task('导入预设', () => client.request('POST', '/v1/presets/import', { preset_id: id.control.value.trim(), preset_json: raw.control.value }));
      // E-P1-5：捕获 import_report 并重新渲染以显示诊断面板。
      // 修复旧 bug：原代码把整个 import 响应灌进 editor，但响应是 {preset_id, prompts_count, import_report}，
      // 不是 canonical preset；正确行为是重新渲染让 selector 显示新导入的 preset。
      state.lastPresetReport = (result && result.import_report) ? result.import_report : null;
      setStatus('预设已导入：' + (result && result.preset_id ? result.preset_id : '') + '（' + (result && result.prompts_count != null ? result.prompts_count : 0) + ' prompts）');
      renderPresets();
    }, 'btn-primary'));
  }

  async function renderPersona() {
    const view = $('#view'); view.replaceChildren(); const box = card('Persona 资料与绑定', true); const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box);
    const user = input('用户 ID', state.userId); form.appendChild(user.wrap);
    const ids = await client.request('GET', '/v1/users/' + encodeURIComponent(state.userId) + '/personas');
    let active = ids[0] || 'default';
    const pick = selector('Persona', ids, active, loadPersona); form.appendChild(pick.wrap);
    const name = input('显示名', ''); const description = input('描述', '', { multiline: true }); const variables = input('变量 JSON', '{}', { multiline: true, code: true }); form.append(name.wrap, description.wrap, variables.wrap);
    const binding = input('绑定角色', state.characterId, { select: state.characters.map(value => ({ value, label: value })) }); form.appendChild(binding.wrap);
    let current;
    async function loadPersona(value) {
      active = value; current = await task('读取 Persona', () => client.request('GET', '/v1/users/' + encodeURIComponent(state.userId) + '/personas/' + encodeURIComponent(active)));
      name.control.value = current.name || ''; description.control.value = current.description || ''; variables.control.value = json(current.variables || {});
    }
    await loadPersona(active);
    const bar = actions();
    bar.append(button('保存', async () => {
      current = await task('保存 Persona', () => client.request('PUT', '/v1/users/' + encodeURIComponent(state.userId) + '/personas/' + encodeURIComponent(active), { expected_revision: current.revision, name: name.control.value, description: description.control.value, variables: parseJson(variables.control.value, '变量') }));
    }, 'btn-primary'));
    bar.append(button('绑定到角色', async () => {
      current = await task('绑定 Persona', () => client.request('POST', '/v1/users/' + encodeURIComponent(state.userId) + '/personas/' + encodeURIComponent(active) + '/bindings', { character_id: binding.control.value }));
    }));
    bar.append(button('解绑角色', async () => {
      if (!binding.control.value) { setStatus('请先选择要解绑的角色', true); return; }
      // daemon `unbind_persona_endpoint` 通过 axum::extract::Query<UnbindPersonaQuery> 读取
      // character_id（必填）与 session_id（可选）；DELETE 不解析 JSON body，
      // 因此必须以 query string 形式传递，否则 400 BadRequest。
      await task('解绑 Persona', () => client.request('DELETE', '/v1/users/' + encodeURIComponent(state.userId) + '/personas/' + encodeURIComponent(active) + '/bindings?character_id=' + encodeURIComponent(binding.control.value)));
    }));
    bar.append(button('删除 Persona', async () => {
      if (active === 'default') { setStatus('不能删除 default Persona', true); return; }
      if (!await AIRPConfirm.confirm('确定删除 Persona「' + active + '」？此操作不可撤销。', { title: '确认删除 Persona' })) return;
      await task('删除 Persona', () => client.request('DELETE', '/v1/users/' + encodeURIComponent(state.userId) + '/personas/' + encodeURIComponent(active)));
      renderPersona();
    }));
    bar.append(button('新建 Persona', async () => {
      const personaId = window.prompt('新 Persona ID'); if (!personaId) return;
      await task('新建 Persona', () => client.request('POST', '/v1/users/' + encodeURIComponent(state.userId) + '/personas', { persona_id: personaId, name: personaId, description: '', variables: {} }));
      renderPersona();
    })); form.appendChild(bar);
    user.control.addEventListener('change', () => { state.userId = user.control.value.trim() || 'default'; sessionStorage.setItem('airp_user_id', state.userId); renderPersona(); });
  }

  async function renderAgent() {
    const view = $('#view'); view.replaceChildren();
    const [tools, settings] = await Promise.all([
      client.request('GET', '/v1/agent/tools'),
      client.request('GET', '/v1/settings'),
    ]);
    const toolAuthorityEnabled = Boolean(settings.access_api_key_set);
    const run = card('受控 Agent 运行', true); const form = node('div', 'runtime-form'); run.appendChild(form); view.appendChild(run);
    form.append(characterSelector(renderAgent).wrap, sessionSelector(renderAgent).wrap);
    const prompt = input('任务', '', { multiline: true, placeholder: '描述本次 Agent 要完成的任务' }); const steps = input('最大步数', '4', { type: 'number' }); const result = output('等待运行…', true); form.append(prompt.wrap, steps.wrap);
    const authorization = node('div', toolAuthorityEnabled ? 'runtime-muted' : 'runtime-warning',
      toolAuthorityEnabled
        ? '默认仅普通生成。勾选下方工具后，本次运行才会获得 call:tool，并且只允许已勾选工具。'
        : '当前 Engine 未配置 AIRP_ACCESS_KEY，本页只能普通生成；工具调用授权已禁用。');
    form.appendChild(authorization);
    const toolList = node('div', 'agent-tool-list' + (toolAuthorityEnabled ? '' : ' disabled'));
    const toolChecks = new Map();
    for (const item of tools) {
      const label = node('label', 'agent-tool');
      const check = document.createElement('input'); check.type = 'checkbox'; check.disabled = !toolAuthorityEnabled;
      const copy = node('span');
      copy.append(node('span', 'agent-tool-name', item.name), node('span', 'agent-tool-meta', item.side_effect + ' · ' + item.description));
      label.append(check, copy); toolList.appendChild(label); toolChecks.set(item.name, check);
    }
    form.appendChild(toolList);
    const bar = actions(); const stop = button('停止', null); stop.disabled = true; let abort;
    const confirm = button('确认执行演练过的破坏性工具', null, 'btn-danger'); confirm.hidden = true;
    let dryRunTools = [];
    function selectedTools() { return [...toolChecks].filter(([, check]) => check.checked).map(([name]) => name); }
    async function startRun(confirmedTools, allowedTools) {
      if (!state.characterId || !state.sessionId || !prompt.control.value.trim()) return;
      start.disabled = true; confirm.disabled = true; stop.disabled = false; result.textContent = ''; abort = new AbortController();
      confirm.hidden = true; dryRunTools = [];
      try {
        await AIRPAgentRun.run(client, {
          characterId: state.characterId,
          sessionId: state.sessionId,
          userId: state.userId,
          message: prompt.control.value.trim(),
          maxSteps: steps.control.value,
          toolAuthorityEnabled,
          tools,
          selectedTools: allowedTools || selectedTools(),
          confirmedTools,
        }, {
          signal: abort.signal,
          onEvent: (item, text) => {
            result.textContent += text + (item.type === 'delta' ? '' : '\n');
            if (item.type === 'tool_result' && item.dry_run && item.tool) dryRunTools.push(item.tool);
          },
          onDone: () => { confirm.hidden = dryRunTools.length === 0; },
        });
        setStatus('Agent 运行完成');
      } catch (error) {
        if (error.name === 'AbortError') setStatus('Agent 运行已停止；不会自动重试，请先刷新历史确认状态');
        else setStatus('Agent 运行失败：' + message(error), true);
      }
      finally { start.disabled = false; confirm.disabled = false; stop.disabled = true; abort = null; }
    }
    const start = button('开始运行', () => startRun([]), 'btn-primary');
    confirm.addEventListener('click', () => {
      const confirmed = [...new Set(dryRunTools)];
      startRun(confirmed, confirmed);
    });
    bar.append(start, stop, confirm); stop.addEventListener('click', () => abort && abort.abort()); form.append(bar, result);
  }

  async function renderSettings() {
    const view = $('#view'); view.replaceChildren(); view.appendChild(connectionCard()); const box = card('Engine 设置', true); const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box);
    const settings = await task('读取设置', () => client.request('GET', '/v1/settings'));
    const endpoint = input('Provider Endpoint', settings.endpoint || ''); const key = input('Provider API Key（留空则不修改）', '', { type: 'password' });
    const engine = input('后端适配器', settings.engine || 'direct', { select: [{ value: 'direct', label: 'OpenAI 兼容 / Direct' }, { value: 'anthropic_messages', label: 'Anthropic Messages' }, { value: 'claude_code_sdk', label: 'Claude Code SDK（后端尚未实现）' }] });
    const volume = input('卷系统 JSON', json(settings.volume_config || {}), { multiline: true, code: true });
    form.append(endpoint.wrap, key.wrap, engine.wrap, volume.wrap);
    // Model picker（保存后自动拉取 /v1/models · 显示上游原始 id）
    const modelPicker = node('div', 'field');
    modelPicker.appendChild(node('span', 'field-label', '模型（保存后自动拉取 /v1/models · 显示上游原始 id）'));
    const modelSelect = node('div', 'model-picker');
    modelSelect.append(node('span', 't-mono', settings.model || '未设置'), node('span', 'mp-arrow', '▾'));
    const modelPill = node('span', 'status-pill neutral'); modelPill.append(node('i', 'dot'), '保存后自动拉取');
    modelPicker.append(modelSelect, modelPill);
    // 降级行（combobox + error code）
    const pickerRow = node('div', 'picker-row');
    const modelField = input('拉取失败时降级为手输（combobox） · 不阻塞保存', settings.model || '', { placeholder: '手输模型 id，如 gpt-4o' });
    modelField.control.classList.add('combobox');
    const comboboxErr = node('span', 'combobox-error'); comboboxErr.style.display = 'none';
    pickerRow.append(modelField.wrap, comboboxErr);
    form.append(modelPicker, pickerRow);
    form.appendChild(node('p', 'runtime-muted', '当前 Provider：' + settings.provider + '；密钥状态：' + (settings.api_key_set ? '已配置' : '未配置') + '。访问密钥不会在此回显。'));
    form.appendChild(button('保存并热更新', async () => {
      const patch = { endpoint: endpoint.control.value.trim(), model: modelField.control.value.trim() || settings.model || '', engine: engine.control.value, volume: parseJson(volume.control.value, '卷系统') }; if (key.control.value) patch.api_key = key.control.value;
      await task('保存设置', () => client.request('POST', '/v1/settings', patch)); key.control.value = '';
    }, 'btn-primary'));
    const raw = card('当前脱敏设置', true); raw.appendChild(output(json(settings), true)); view.appendChild(raw);
  }

  async function renderMemory() {
    const view = $('#view'); view.replaceChildren();
    const resident = card('会话常驻记忆', false); const rf = node('div', 'runtime-form'); resident.appendChild(rf); view.appendChild(resident); rf.append(characterSelector(renderMemory).wrap, sessionSelector(renderMemory).wrap);
    let memory = state.characterId ? await client.request('GET', '/v1/memory/resident?character_id=' + encodeURIComponent(state.characterId) + (state.sessionId ? '&session_id=' + encodeURIComponent(state.sessionId) : '')) : { content: '', capacity: 0, char_count: 0 };
    // 容量进度条
    const capBar = node('div', 'cap-bar'); const capFill = node('div', 'cap-fill'); const pct = memory.capacity ? Math.min(100, Math.round((memory.char_count || 0) / memory.capacity * 100)) : 0; capFill.style.width = pct + '%'; if (pct > 80) capFill.classList.add('cap-warn'); capBar.appendChild(capFill);
    const capLabel = node('div', 'runtime-muted', (memory.char_count || 0) + ' / ' + (memory.capacity || 0) + ' 字符（' + pct + '%）' + (pct > 80 ? ' · 接近容量上限，超限后自动 LLM 压缩' : ''));
    rf.append(capBar, capLabel);
    rf.append(node('p', 'runtime-muted', '每轮对话结束后，Engine 自动从助手回复中抽取事实并追加到常驻记忆；超过容量时触发 LLM 压缩合并。'));
    const re = input('内容', memory.content || '', { multiline: true, code: true }); rf.append(re.wrap, button('保存常驻记忆', () => task('保存常驻记忆', () => client.request('PUT', '/v1/memory/resident', { character_id: state.characterId, session_id: state.sessionId || null, content: re.control.value })), 'btn-primary'));
    const user = card('用户模型', false); const uf = node('div', 'runtime-form'); user.appendChild(uf); view.appendChild(user); const uid = input('用户 ID', state.userId); const um = await client.request('GET', '/v1/memory/user-model?user_id=' + encodeURIComponent(state.userId)); const ue = input('内容', um.content || '', { multiline: true, code: true }); uf.append(uid.wrap, ue.wrap, button('保存用户模型', () => task('保存用户模型', () => client.request('PUT', '/v1/memory/user-model', { user_id: uid.control.value.trim(), content: ue.control.value })), 'btn-primary'));
    const stateCard = card('角色实时状态', true); if (state.characterId) { const live = await client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/state').catch(error => ({ unavailable: message(error) })); stateCard.appendChild(output(json(live), true)); } view.appendChild(stateCard);
    const historyCard = card('状态变更历史', true); if (state.characterId) { const history = await client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/state/history').catch(error => ({ unavailable: message(error) })); historyCard.appendChild(output(json(history), true)); } view.appendChild(historyCard);
    const schemaCard = card('状态 JSON Schema', true); if (state.characterId) { const schema = await client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/state/schema').catch(error => ({ unavailable: message(error) })); schemaCard.appendChild(output(json(schema), true)); } view.appendChild(schemaCard);
  }

  async function renderScenes() {
    const view = $('#view'); view.replaceChildren(); const ids = await client.request('GET', '/v1/scenes');
    const list = card('场景列表', false); const rows = node('div', 'runtime-list'); list.appendChild(rows); view.appendChild(list);
    const editorCard = card('场景 JSON', false); const editor = input('创建或整体替换', json({ scene_id: '', description: '', characters: [], narrator_style: '', lorebook_merge: 'union', format_hint: '' }), { multiline: true, code: true }); editorCard.appendChild(editor.wrap); const save = button('保存场景', async () => { await task('保存场景', () => client.request('POST', '/v1/scenes', parseJson(editor.control.value, '场景'))); renderScenes(); }, 'btn-primary'); editorCard.appendChild(save); view.appendChild(editorCard);
    if (!ids.length) rows.appendChild(node('p', 'runtime-muted', '尚未创建场景。'));
    for (const id of ids) {
      const row = node('div', 'runtime-row');
      const main = node('div', 'runtime-row-main');
      main.appendChild(node('div', 'runtime-row-title', id));
      const meta = node('div', 'runtime-row-meta', ''); main.appendChild(meta);
      const ops = node('div', 'op-col');
      ops.appendChild(button('编辑', async () => { editor.control.value = json(await task('读取场景', () => client.request('GET', '/v1/scenes/' + encodeURIComponent(id)))); }));
      // Phase 1.3: 场景添加角色 UI
      ops.appendChild(button('+ 角色', async () => {
        const scene = await task('读取场景', () => client.request('GET', '/v1/scenes/' + encodeURIComponent(id)));
        meta.textContent = '已有角色: ' + ((scene.characters || []).map(c => c.character_id || c).join(', ') || '无');
        const oldForm = row.querySelector('.add-char-form'); if (oldForm) { oldForm.remove(); return; }
        const addForm = node('div', 'add-char-form runtime-form');
        const charPick = input('角色 ID', state.characterId || '', { select: state.characters.map(v => ({ value: v, label: v })) });
        // B2 修复：对齐 Engine CharacterRole 枚举（scene.rs:8-14 仅 Primary/Npc，snake_case 为 primary/npc）
        const rolePick = input('角色类型', 'primary', { select: [{ value: 'primary', label: '主角 (primary)' }, { value: 'npc', label: 'NPC (npc)' }] });
        const addBtn = button('添加到场景', async () => {
          await task('添加角色到场景', () => client.request('POST', '/v1/scenes/' + encodeURIComponent(id) + '/characters', { character_id: charPick.control.value, role: rolePick.control.value }));
          setStatus('角色 ' + charPick.control.value + ' 已添加到场景 ' + id);
          addForm.remove();
          // N-D：递增 metaToken 使初始 fetch 的 stale 响应失效
          if (row._metaToken) row._metaToken.version++;
          const updated = await client.request('GET', '/v1/scenes/' + encodeURIComponent(id));
          meta.textContent = '已有角色: ' + ((updated.characters || []).map(c => c.character_id || c).join(', ') || '无');
        }, 'btn-primary');
        addForm.append(charPick.wrap, rolePick.wrap, addBtn);
        row.after(addForm);
      }));
      row.append(main, ops);
      rows.appendChild(row);
      // N-D 修复：场景元信息异步获取竞态——用 metaToken 防止初始 fetch 的 stale 响应覆盖添加角色后的最新 meta
      const metaToken = { version: 0 };
      row._metaToken = metaToken;
      client.request('GET', '/v1/scenes/' + encodeURIComponent(id)).then(scene => {
        if (metaToken.version !== 0) return; // 已被添加角色操作递增，丢弃 stale 响应
        meta.textContent = '已有角色: ' + ((scene.characters || []).map(c => c.character_id || c).join(', ') || '无');
      }).catch(() => {});
    }
    // World Events 面板
    const weCard = card('世界事件 (World Events)', false);
    const weForm = node('div', 'runtime-form'); weCard.appendChild(weForm);
    weForm.append(characterSelector(renderScenes).wrap);
    const weList = node('div', 'runtime-list'); weForm.appendChild(weList);
    view.appendChild(weCard);
    if (state.characterId) {
      try {
        const events = await client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/world-events');
        if (!Array.isArray(events) || !events.length) { weList.appendChild(node('p', 'runtime-muted', '该角色没有定义世界事件。')); }
        else events.forEach(ev => {
          const row = node('div', 'runtime-row');
          const main = node('div', 'runtime-row-main');
          main.append(node('div', 'runtime-row-title', (ev.triggered ? '✓ ' : '○ ') + (ev.name || ev.id)), node('div', 'runtime-row-meta', (ev.description || '') + (ev.trigger_keywords && ev.trigger_keywords.length ? ' · 关键词: ' + ev.trigger_keywords.join(', ') : '')));
          row.appendChild(main); weList.appendChild(row);
        });
      } catch (error) { weList.appendChild(node('p', 'runtime-muted', '加载失败：' + message(error))); }
    } else { weList.appendChild(node('p', 'runtime-muted', '选择角色后加载世界事件。')); }
  }

  async function renderBranches() {
    const view = $('#view'); view.replaceChildren(); const box = card('会话分支与候选回复', true); const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box); form.append(characterSelector(renderBranches).wrap, sessionSelector(renderBranches).wrap);
    if (!state.characterId || !state.sessionId) { form.appendChild(node('p', 'runtime-muted', '请选择已有会话。')); return; }
    const data = await task('读取分支', () => client.request('POST', '/v1/chat/history', { character_id: state.characterId, session_id: state.sessionId, limit: 200 }));
    const list = node('div', 'runtime-list'); form.appendChild(list);
    (data.messages || []).forEach((item, index) => {
      const id = data.message_ids[index]; const candidates = data.message_candidates[index] || []; const active = data.message_swipe_index[index] || 0; const row = node('div', 'runtime-row'); const copy = node('div', 'runtime-row-main'); copy.append(node('div', 'runtime-row-title', (item.role || 'message') + ' · ' + String(item.content || '').slice(0, 100)), node('div', 'runtime-row-meta', id + ' · parent ' + (data.message_parents[index] || 'root') + (data.active_path.includes(id) ? ' · active' : '')));
      const bar = actions(); if (candidates.length > 1) candidates.forEach((candidate, candidateIndex) => bar.appendChild(button((candidateIndex === active ? '● ' : '') + (candidateIndex + 1) + '/' + candidates.length, async () => { await task('切换候选', () => client.request('POST', '/v1/chat/swipe', { character_id: state.characterId, session_id: state.sessionId, message_id: id, index: candidateIndex })); renderBranches(); })));
      const isLeaf = !(data.message_parents || []).includes(id); if (isLeaf && id !== data.active_leaf) bar.appendChild(button('切到此分支', async () => { await task('切换分支', () => client.request('POST', '/v1/chat/branch/switch', { character_id: state.characterId, session_id: state.sessionId, target_leaf_id: id })); renderBranches(); })); row.append(copy, bar); list.appendChild(row);
    });
  }

  async function renderPreview() {
    const view = $('#view'); view.replaceChildren();
    const box = card('Prompt 装配预览（无模型调用、无写入）', true);
    const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box);
    form.append(characterSelector(renderPreview).wrap, sessionSelector(renderPreview).wrap);
    const prompt = input('模拟用户消息', '测试消息', { multiline: true });
    const result = output('点击预览后显示脱敏装配轨迹。', true);
    form.append(prompt.wrap, button('生成预览', async () => {
      const data = await task('生成装配预览', () => client.request('POST', '/v1/chat/preview', {
        character_id: state.characterId,
        session_id: state.sessionId || null,
        user_id: state.userId,
        user_profile: { name: state.userId, variables: {} },
        message: prompt.control.value,
      }));
      result.textContent = json(data);
    }, 'btn-primary'), result);
  }

  async function renderQuota() {
    const view = $('#view'); view.replaceChildren(); const settings = await client.request('GET', '/v1/settings'); const box = card('每日配额策略', true); const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box); const editor = input('Quota JSON', json(settings.quota || {}), { multiline: true, code: true }); form.append(editor.wrap, node('p', 'runtime-warning', '这是 Engine 的配额策略，不是实时计费账单。保存后影响后续请求。'), button('保存配额策略', () => task('保存配额', () => client.request('POST', '/v1/settings', { quota: parseJson(editor.control.value, 'Quota') })), 'btn-primary'));
  }

  async function renderDiagnostics() {
    const view = $('#view'); view.replaceChildren(); const box = card('Engine 诊断快照', true); view.appendChild(box); const result = {};
    for (const [name, path] of [['version', '/version'], ['health', '/health'], ['settings', '/v1/settings'], ['characters', '/v1/characters'], ['presets', '/v1/presets'], ['scenes', '/v1/scenes'], ['agent_tools', '/v1/agent/tools']]) {
      try { result[name] = { ok: true, data: await client.request('GET', path) }; } catch (error) { result[name] = { ok: false, error: message(error), status: error.status || 0 }; }
    }
    box.appendChild(output(json(result), true));

    // BUG-2 缓解切片：被 TurnCommit marker fail-closed 锁死的会话，在这里提供
    // 状态展示 + 恢复入口（归档 marker、不删数据；replay 尚未交付）。
    const recoverBox = card('会话恢复（写入中断锁死）', true);
    view.appendChild(recoverBox);
    const recoverForm = node('div', 'runtime-form'); recoverBox.appendChild(recoverForm);
    const phaseLine = node('p', 'runtime-muted', '正在检查当前会话状态…');
    recoverForm.appendChild(phaseLine);
    const readSessionState = async () => {
      if (!state.characterId) { phaseLine.textContent = '请先在角色列表选择角色。'; return null; }
      try {
        const st = await client.request('POST', '/v1/chat/session-state', { character_id: state.characterId, session_id: state.sessionId || null });
        const phase = st && st.phase || 'unknown';
        phaseLine.textContent = '当前会话状态：' + phase + (st && st.generation_id ? '（generation ' + st.generation_id + '）' : '') + (phase === 'recovering' ? ' —— 会话被未完成的写入标记锁定，可尝试恢复。' : '');
        return st;
      } catch (error) { phaseLine.textContent = '状态查询失败：' + message(error); return null; }
    };
    await readSessionState();
    const recoverBtn = button('尝试恢复会话', async () => {
      if (!state.characterId) { setStatus('请先选择角色', true); return; }
      if (!await AIRPConfirm.confirm('恢复会隔离未完成的提交标记（不会删除任何消息数据），然后允许继续对话。继续吗？', { title: '确认恢复会话' })) return;
      try {
        const resp = await task('会话恢复', () => client.request('POST', '/v1/chat/session-recover', { character_id: state.characterId, session_id: state.sessionId || null }));
        phaseLine.textContent = '已恢复；标记已归档到：' + (resp && resp.quarantined_marker || 'quarantine 目录');
        await readSessionState();
      } catch (error) { /* task 已写入状态栏；保留诊断行供重试 */ }
    }, 'btn-primary');
    recoverForm.append(recoverBtn, button('刷新状态', readSessionState), node('p', 'runtime-muted', '仅当会话处于 recovering 状态时可用；原始标记移入 quarantine 目录而非删除，供后续 replay 或人工检查。'));
  }

  async function renderNotes() {
    const view = $('#view'); view.replaceChildren();
    const box = card('本机连接备注', true); const form = node('div', 'runtime-form'); box.appendChild(form); view.appendChild(box);
    const editor = input('只保存在当前浏览器中的备注', localStorage.getItem('airp_console_notes') || '', { multiline: true, code: true });
    form.append(editor.wrap, node('p', 'runtime-muted', '备注不会发送给 Engine，也不会进入角色、会话或备份。'), button('保存本机备注', () => { localStorage.setItem('airp_console_notes', editor.control.value); setStatus('本机备注已保存'); }, 'btn-primary'));
  }

  async function renderStyle() {
    const view = $('#view'); view.replaceChildren();
    const driftCard = card('Soul-Drift 风格漂移', true);
    const form = node('div', 'runtime-form'); driftCard.appendChild(form);
    form.append(characterSelector(renderStyle).wrap);
    const driftInfo = node('div', 'runtime-muted', '选择角色后加载漂移状态');
    const driftEditor = input('漂移内容', '', { multiline: true, code: true });
    const saveBtn = button('保存漂移', async () => {
      if (!state.characterId) return;
      await task('保存 Soul-Drift', () => client.request('PUT', '/v1/characters/' + encodeURIComponent(state.characterId) + '/drift', { content: driftEditor.control.value }));
      setStatus('Soul-Drift 已保存');
      if (state.characterId) loadDrift();
    }, 'btn-primary');
    // Phase 1.2: Drift 回滚按钮
    const rollbackBtn = button('回滚到上一版本', async () => {
      if (!state.characterId) return;
      const currentRev = driftEditor.control.dataset.revision;
      if (!currentRev || Number(currentRev) <= 1) { setStatus('没有可回滚的历史版本', true); return; }
      const targetRev = Number(currentRev) - 1;
      if (!await AIRPConfirm.confirm('确定回滚到 revision ' + targetRev + '？当前内容将被替换。', { title: '确认回滚 Soul-Drift' })) return;
      await task('回滚 Soul-Drift', () => client.request('POST', '/v1/characters/' + encodeURIComponent(state.characterId) + '/drift/rollback', { revision: targetRev }));
      setStatus('Soul-Drift 已回滚到 revision ' + targetRev);
      loadDrift();
    });
    form.append(driftInfo, driftEditor.wrap, saveBtn, rollbackBtn);
    view.appendChild(driftCard);

    const reviewCard = card('风格审查 (Style Review)', false);
    const reviewForm = node('div', 'runtime-form'); reviewCard.appendChild(reviewForm);
    const reviewBtn = button('运行风格审查', async () => {
      if (!state.characterId) { setStatus('请先选择角色', true); return; }
      reviewBtn.disabled = true; reviewBtn.textContent = '审查中…';
      try {
        const resp = await task('风格审查', () => client.request('POST', '/v1/style/review', { character_id: state.characterId, session_id: state.sessionId || null }));
        renderReviewResult(reviewForm, resp);
        setStatus(resp.drift_applied ? '审查完成，漂移已更新' : '审查完成');
        // 刷新漂移显示
        if (state.characterId) loadDrift();
      } catch (error) { setStatus('审查失败：' + message(error), true); }
      finally { reviewBtn.disabled = false; reviewBtn.textContent = '运行风格审查'; }
    }, 'btn-primary');
    reviewForm.append(node('p', 'runtime-muted', '对比风格指南与最近 10 条助手回复，检查语气/视角/节奏偏移。需要 Provider 已配置。'), reviewBtn);
    view.appendChild(reviewCard);

    function renderReviewResult(container, resp) {
      const old = container.querySelector('.review-result'); if (old) old.remove();
      const box = node('div', 'review-result');
      const report = resp.report || {};
      box.appendChild(node('div', 'runtime-row-title', '语气偏移'));
      box.appendChild(node('div', 'runtime-muted', report.tone_drift || '无'));
      if (report.perspective_issues && report.perspective_issues.length) {
        box.appendChild(node('div', 'runtime-row-title', '视角问题'));
        report.perspective_issues.forEach(issue => box.appendChild(node('div', 'runtime-muted', '• ' + issue)));
      }
      box.appendChild(node('div', 'runtime-row-title', '节奏'));
      box.appendChild(node('div', 'runtime-muted', report.pacing_notes || '无'));
      if (report.suggestions && report.suggestions.length) {
        box.appendChild(node('div', 'runtime-row-title', '建议'));
        report.suggestions.forEach(s => box.appendChild(node('div', 'runtime-muted', '• ' + s)));
      }
      if (report.drift_patch) {
        box.appendChild(node('div', 'runtime-row-title', 'Drift Patch'));
        const pre = node('div', 'runtime-code', report.drift_patch); box.appendChild(pre);
      }
      container.appendChild(box);
    }

    async function loadDrift() {
      if (!state.characterId) { driftInfo.textContent = '选择角色后加载漂移状态'; return; }
      try {
        const drift = await client.request('GET', '/v1/characters/' + encodeURIComponent(state.characterId) + '/drift');
        driftInfo.textContent = (drift.char_count || 0) + ' / ' + (drift.capacity || 0) + ' 字符 · revision ' + (drift.revision != null ? drift.revision : '—');
        driftEditor.control.value = drift.content || '';
        driftEditor.control.dataset.revision = drift.revision != null ? drift.revision : '';
      } catch (error) { driftInfo.textContent = '加载失败：' + message(error); }
    }
    // 角色选择后自动加载
    const origSelector = form.querySelector('select');
    if (origSelector) origSelector.addEventListener('change', loadDrift);
    if (state.characterId) loadDrift();
  }

  // #342 E-P2-1：备份恢复闭环 WebUI 入口。替换原 renderUnavailable('backup')。
  // 调用契约：GET /v1/backups（列表）、POST /v1/backups（创建）、
  // POST /v1/backups/:id/verify（校验）、POST /v1/backups/:id/restore（恢复）、
  // DELETE /v1/backups/:id（删除）。secret 文件（secrets.json / settings.json）
  // 由 Engine denylist 排除，restore 后需手动重配 provider key。
  async function renderBackup() {
    const BACKUP_SOURCE_LABELS = { manual: '手动', pre_delete: '删除前', pre_restore_rollback: '恢复前回滚' };
    const BACKUP_SCOPE_KIND_LABELS = { full: '全量', character: '角色', session: '会话' };

    function formatBytes(n) {
      if (n == null) return '—';
      if (n < 1024) return n + ' B';
      if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
      if (n < 1024 * 1024 * 1024) return (n / (1024 * 1024)).toFixed(1) + ' MB';
      return (n / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    }

    function formatTimestamp(iso) {
      if (!iso) return '—';
      // Engine 返回 RFC3339 UTC；本地展示按浏览器时区
      const d = new Date(iso);
      if (Number.isNaN(d.getTime())) return iso;
      return d.toLocaleString();
    }

    function describeScope(scope) {
      if (!scope || typeof scope !== 'object') return '—';
      const kind = scope.kind;
      const kindLabel = BACKUP_SCOPE_KIND_LABELS[kind] || kind;
      if (kind === 'full') return kindLabel;
      if (kind === 'character') return kindLabel + '：' + (scope.character_id || '?');
      if (kind === 'session') return kindLabel + '：' + (scope.character_id || '?') + '/' + (scope.session_id || '?');
      return kindLabel;
    }

    function describeVerified(verified) {
      if (verified === true) return '已校验';
      if (verified === false) return '校验失败';
      return '未校验';
    }

    const view = $('#view'); view.replaceChildren();
    const createCard = card('创建备份', true);
    view.appendChild(createCard);
    createCard.appendChild(node('div', 'runtime-warning',
      '备份会排除 secrets.json 与 settings.json（含 provider key 与 access key）。' +
      '备份期间建议暂停写入（维护窗口），避免并发写产生混合快照。'));
    const form = node('div', 'runtime-form'); createCard.appendChild(form);
    const scopeKind = input('备份范围', 'full', {
      select: [
        { value: 'full', label: '全量' },
        { value: 'character', label: '单角色' },
        { value: 'session', label: '单会话' },
      ],
    });
    form.append(scopeKind.wrap);
    // scope-dependent ID inputs
    const charOptions = state.characters.map(v => ({ value: v, label: v }));
    const charIdInput = input('角色 ID', state.characterId || '', { select: charOptions.length ? charOptions : [{ value: '', label: '无可用角色' }] });
    const sessOptions = state.sessions.map(v => ({ value: v, label: v }));
    const sessIdInput = input('会话 ID', state.sessionId || '', { select: sessOptions.length ? sessOptions : [{ value: '', label: '无可用会话' }] });
    form.append(charIdInput.wrap, sessIdInput.wrap);
    const refreshScopeInputs = () => {
      const kind = scopeKind.control.value;
      charIdInput.wrap.style.display = kind === 'character' || kind === 'session' ? '' : 'none';
      sessIdInput.wrap.style.display = kind === 'session' ? '' : 'none';
    };
    scopeKind.control.addEventListener('change', refreshScopeInputs);
    refreshScopeInputs();
    const createBtn = button('创建备份', async () => {
      const kind = scopeKind.control.value;
      let scopeBody;
      if (kind === 'full') {
        scopeBody = { kind: 'full' };
      } else if (kind === 'character') {
        const cid = charIdInput.control.value.trim();
        if (!cid) { setStatus('请填写角色 ID', true); return; }
        scopeBody = { kind: 'character', character_id: cid };
      } else {
        const cid = charIdInput.control.value.trim();
        const sid = sessIdInput.control.value.trim();
        if (!cid || !sid) { setStatus('请填写角色 ID 与会话 ID', true); return; }
        scopeBody = { kind: 'session', character_id: cid, session_id: sid };
      }
      if (!await AIRPConfirm.confirm('即将创建备份。secrets.json 与 settings.json 会被排除。备份期间请暂停写入。继续？', { title: '确认创建备份', danger: false })) return;
      try {
        await task('创建备份', () => client.request('POST', '/v1/backups', { source: 'manual', scope: scopeBody }));
        setStatus('备份已创建');
        loadList();
      } catch (error) { /* task 已 setStatus */ }
    }, 'btn-primary');
    form.append(createBtn);

    const listBox = card('已有备份', true);
    view.appendChild(listBox);
    const listInfo = node('p', 'runtime-muted', '');
    listBox.appendChild(listInfo);
    const listContainer = node('div', 'runtime-list'); listBox.appendChild(listContainer);
    const refreshBtn = button('刷新列表', () => loadList());
    listBox.appendChild(refreshBtn);

    async function loadList() {
      listContainer.replaceChildren();
      listInfo.textContent = '加载中…';
      let items;
      try {
        items = await task('加载备份列表', () => client.request('GET', '/v1/backups'));
      } catch (error) {
        listInfo.textContent = '加载失败：' + message(error);
        return;
      }
      if (!Array.isArray(items) || !items.length) {
        listInfo.textContent = '暂无备份';
        return;
      }
      listInfo.textContent = '共 ' + items.length + ' 个备份（按创建时间降序）';
      items.forEach(item => listContainer.appendChild(renderBackupRow(item, loadList)));
    }

    function renderBackupRow(item, reload) {
      const row = node('div', 'runtime-card runtime-backup-row');
      const head = node('div', 'runtime-row-title');
      const shortId = (item.backup_id || '').slice(0, 8);
      head.appendChild(node('span', '', shortId));
      const sourceLabel = BACKUP_SOURCE_LABELS[item.source] || item.source;
      head.appendChild(node('span', 'import-report-tag ' + (item.source === 'manual' ? 'ok' : 'warn'), sourceLabel));
      head.appendChild(node('span', 'runtime-muted', describeVerified(item.verified)));
      row.appendChild(head);
      const meta = node('dl', 'runtime-kv');
      const appendMeta = (label, value) => {
        meta.appendChild(node('dt', '', label));
        meta.appendChild(node('dd', '', value));
      };
      appendMeta('创建时间', formatTimestamp(item.created_at));
      appendMeta('范围', describeScope(item.scope));
      appendMeta('文件数', String(item.files_count ?? '—'));
      appendMeta('总字节', formatBytes(item.total_bytes));
      row.appendChild(meta);
      const actionBox = actions();
      row.appendChild(actionBox);
      actionBox.appendChild(button('校验', async () => {
        try {
          const resp = await task('校验备份', () => client.request('POST', '/v1/backups/' + encodeURIComponent(item.backup_id) + '/verify'));
          setStatus('校验通过：' + resp.checked_files + ' 文件，tree=' + (resp.tree_sha256 || '').slice(0, 12) + '…');
          reload();
        } catch (error) { /* task 已 setStatus */ }
      }));
      actionBox.appendChild(button('恢复', async () => {
        const ok = await AIRPConfirm.confirm(
          '确定从备份 ' + shortId + ' 恢复？\n\n' +
          '此操作会：\n' +
          '1. 自动创建一个回滚备份（保护当前 data_root 状态）\n' +
          '2. 用备份内容覆盖 data_root 下所有非 backup 文件\n' +
          '3. secrets.json / settings.json 不会被恢复，需手动重新配置 provider key 与 access key\n' +
          '4. 建议恢复后重启 daemon，避免运行中状态与新数据不一致\n\n' +
          '继续？',
          { title: '确认恢复备份' }
        );
        if (!ok) return;
        try {
          const resp = await task('恢复备份', () => client.request('POST', '/v1/backups/' + encodeURIComponent(item.backup_id) + '/restore'));
          setStatus('已恢复（回滚备份 id=' + (resp.rollback_backup_id || '').slice(0, 8) + '…），建议重启 daemon');
          reload();
        } catch (error) { /* task 已 setStatus */ }
      }));
      actionBox.appendChild(button('删除', async () => {
        if (!await AIRPConfirm.confirm('确定删除备份 ' + shortId + '？此操作不可恢复。', { title: '确认删除备份' })) return;
        try {
          await task('删除备份', () => client.request('DELETE', '/v1/backups/' + encodeURIComponent(item.backup_id)));
          setStatus('备份已删除');
          reload();
        } catch (error) { /* task 已 setStatus */ }
      }, 'btn-danger'));
      return row;
    }

    loadList();
  }

  // C-P3：扩展管理 UI——install / enable / disable / delete / grant 消费面。
  // 与 renderBackup 同模式：card + runtime-list + 内联操作。安全提示明示
  // 「安装即信任」「capability 授权由 engine 权威签发」「digest-pinned 锚定」。
  // 端点合同：POST /v1/extensions/install、GET /v1/extensions、
  // POST /v1/extensions/:id/enable|disable、DELETE /v1/extensions/:id、
  // POST /v1/extensions/:id/grants（action=grant|revoke，capabilities 可选子集）。
  async function renderPlugins() {
    const view = $('#view'); view.replaceChildren();

    const securityCard = card('扩展管理', true);
    securityCard.appendChild(node('div', 'runtime-warning',
      '扩展是第三方代码。安装即信任——我们不审计 widget 代码，安装/批准它是用户的选择与风险（docs/SECURITY.md）。' +
      'capability 授权由 engine 权威签发（POST /v1/extensions/:id/grants），consent.js 仅维护内存镜像。'));
    view.appendChild(securityCard);

    const listCard = card('已安装扩展', true);
    view.appendChild(listCard);
    const listInfo = node('p', 'runtime-muted', '');
    listCard.appendChild(listInfo);
    const listContainer = node('div', 'runtime-list'); listCard.appendChild(listContainer);
    listCard.appendChild(button('刷新列表', () => loadList()));

    // C-P4 第二批（#484）：授权总览卡——消费统一授权查询面 GET /v1/grants
    // （kind 判别字段聚合全部授权主体；本阶段仅 widget，后续 MCP/plugin
    // additive 追加 kind）。只读总览，签发/撤销仍走各主体自己的端点。
    const grantsCard = card('授权总览（统一面）', true);
    view.appendChild(grantsCard);
    grantsCard.appendChild(node('p', 'runtime-muted',
      '数据源：GET /v1/grants（engine 统一授权查询面）。kind 判别字段区分授权主体类型，' +
      '当前仅 widget 扩展；新增主体（如 MCP）接入时本卡自动分 kind 呈现。'));
    const grantsInfo = node('p', 'runtime-muted', '');
    grantsCard.appendChild(grantsInfo);
    const grantsContainer = node('div', 'runtime-list'); grantsCard.appendChild(grantsContainer);

    async function loadGrantsOverview() {
      grantsContainer.replaceChildren();
      grantsInfo.textContent = '加载中…';
      let grants;
      try {
        const resp = await task('加载授权总览', () => client.request('GET', '/v1/grants', undefined, {
          signal: AbortSignal.timeout(5000),
        }));
        grants = (resp && resp.grants) || [];
      } catch (error) {
        grantsInfo.textContent = '加载失败：' + message(error);
        return;
      }
      if (!grants.length) {
        grantsInfo.textContent = '暂无授权主体（尚未安装扩展）';
        return;
      }
      const grantedCount = grants.filter(g => (g.granted_capabilities || []).length > 0).length;
      grantsInfo.textContent = '共 ' + grants.length + ' 个授权主体，其中 ' + grantedCount + ' 个已签发 capability';
      grants.forEach(grant => {
        const row = node('div', 'runtime-card runtime-extension-row');
        const head = node('div', 'runtime-row-title');
        head.appendChild(node('span', 'import-report-tag', grant.kind || 'unknown'));
        head.appendChild(node('span', '', grant.type || grant.id || '?'));
        const caps = grant.granted_capabilities || [];
        head.appendChild(node('span', 'import-report-tag ' + (caps.length ? 'ok' : 'warn'),
          caps.length ? '已授权 ' + caps.length + ' 项' : '未授权'));
        row.appendChild(head);
        const meta = node('dl', 'runtime-kv');
        meta.appendChild(node('dt', '', 'ID'));
        meta.appendChild(node('dd', '', grant.id || '?'));
        meta.appendChild(node('dt', '', '已授权'));
        meta.appendChild(node('dd', '', caps.join(', ') || '—'));
        if (grant.granted_at) {
          meta.appendChild(node('dt', '', '授权时间'));
          meta.appendChild(node('dd', '', new Date(grant.granted_at * 1000).toLocaleString()));
        }
        row.appendChild(meta);
        grantsContainer.appendChild(row);
      });
    }
    loadGrantsOverview();

    async function loadList() {
      listContainer.replaceChildren();
      listInfo.textContent = '加载中…';
      let items;
      try {
        const resp = await task('加载扩展列表', () => client.request('GET', '/v1/extensions'));
        items = (resp && resp.extensions) || [];
      } catch (error) {
        listInfo.textContent = '加载失败：' + message(error);
        return;
      }
      if (!items.length) {
        listInfo.textContent = '暂无已安装扩展';
        return;
      }
      listInfo.textContent = '共 ' + items.length + ' 个扩展';
      items.forEach(item => listContainer.appendChild(renderExtensionRow(item, reloadAll)));
    }

    // 列表与授权总览同源变更（grant/revoke/删除），统一刷新。
    function reloadAll() {
      loadList();
      loadGrantsOverview();
    }

    function renderExtensionRow(item, reload) {
      const row = node('div', 'runtime-card runtime-extension-row');
      const head = node('div', 'runtime-row-title');
      const widgetType = (item.manifest && item.manifest.type) || item.type || '?';
      head.appendChild(node('span', '', widgetType));
      head.appendChild(node('span', 'runtime-muted', 'v' + ((item.manifest && item.manifest.version) || item.version || '?')));
      head.appendChild(node('span', 'import-report-tag ' + (item.enabled ? 'ok' : 'warn'), item.enabled ? '已启用' : '已停用'));
      const grantedCount = (item.granted_capabilities && item.granted_capabilities.length) || 0;
      head.appendChild(node('span', 'import-report-tag ' + (grantedCount ? 'ok' : 'warn'), grantedCount ? '已授权 ' + grantedCount + ' 项' : '未授权'));
      row.appendChild(head);

      const meta = node('dl', 'runtime-kv');
      const appendMeta = (label, value) => {
        meta.appendChild(node('dt', '', label));
        meta.appendChild(node('dd', '', value));
      };
      appendMeta('ID', item.id || '?');
      appendMeta('Digest', (item.digest || '').slice(0, 12) + '…');
      appendMeta('Slot', item.slot || '—');
      appendMeta('Capabilities', ((item.manifest && item.manifest.capabilities) || []).join(', ') || '—');
      appendMeta('已授权', (item.granted_capabilities || []).join(', ') || '—');
      if (item.granted_at) {
        appendMeta('授权时间', new Date(item.granted_at * 1000).toLocaleString());
      }
      row.appendChild(meta);

      let grantPanel = null;
      const actionBox = actions();
      row.appendChild(actionBox);

      // 启用/停用：路径用纯字面量拼接，便于 endpoint-guard 静态解析
      // （ternary 表达式会被 staticPath 截断为 :param，无法匹配子路径）。
      if (item.enabled) {
        actionBox.appendChild(button('停用', async () => {
          try {
            await task('停用扩展',
              () => client.request('POST', '/v1/extensions/' + encodeURIComponent(item.id) + '/disable'));
            reload();
          } catch (error) { /* task 已 setStatus */ }
        }));
      } else {
        actionBox.appendChild(button('启用', async () => {
          try {
            await task('启用扩展',
              () => client.request('POST', '/v1/extensions/' + encodeURIComponent(item.id) + '/enable'));
            reload();
          } catch (error) { /* task 已 setStatus */ }
        }));
      }

      actionBox.appendChild(button('授权管理', () => {
        if (grantPanel) {
          grantPanel.remove();
          grantPanel = null;
          return;
        }
        grantPanel = renderGrantPanel(item, reload);
        row.appendChild(grantPanel);
      }));

      actionBox.appendChild(button('删除', async () => {
        if (!await AIRPConfirm.confirm('确定删除扩展 ' + widgetType + '？此操作不可恢复，相关文件目录会被清理。', { title: '确认删除扩展' })) return;
        try {
          await task('删除扩展', () => client.request('DELETE', '/v1/extensions/' + encodeURIComponent(item.id)));
          reload();
        } catch (error) { /* task 已 setStatus */ }
      }, 'btn-danger'));

      return row;
    }

    function renderGrantPanel(item, reload) {
      const panel = node('div', 'runtime-grant-panel');
      panel.appendChild(node('h3', '', 'Capability 授权管理'));
      panel.appendChild(node('p', 'runtime-muted',
        'engine 权威签发 grant 后，consent.js 在下次 boot 时同步缓存，widget 才能挂载与发起 intent。' +
        '未声明的 capability 不可授权（manifest 约束）。'));
      const declared = (item.manifest && item.manifest.capabilities) || [];
      const granted = new Set(item.granted_capabilities || []);
      if (!declared.length) {
        panel.appendChild(node('p', 'runtime-warning', '该扩展未声明任何 capability，无需授权。'));
        return panel;
      }
      const checkboxes = [];
      declared.forEach(cap => {
        const label = node('label', 'runtime-checkbox-row');
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.checked = granted.has(cap);
        label.appendChild(cb);
        label.appendChild(node('span', '', cap));
        panel.appendChild(label);
        checkboxes.push({ cap: cap, cb: cb });
      });
      const grantActions = actions();
      panel.appendChild(grantActions);
      grantActions.appendChild(button('保存授权', async () => {
        const selected = checkboxes.filter(c => c.cb.checked).map(c => c.cap);
        const ok = await AIRPConfirm.confirm(
          '即将为 ' + ((item.manifest && item.manifest.type) || item.id) + ' 签发授权：\n' +
          (selected.length ? selected.join('\n') : '（清空，撤销全部授权）') + '\n\n' +
          '授权后 widget 即可发起对应 capability 的 intent。继续？',
          { title: '确认更新扩展授权', danger: false }
        );
        if (!ok) return;
        try {
          const body = selected.length
            ? { action: 'grant', capabilities: selected }
            : { action: 'revoke' };
          await task('保存授权', () => client.request('POST',
            '/v1/extensions/' + encodeURIComponent(item.id) + '/grants', body, {
              signal: AbortSignal.timeout(5000),
            }));
          reload();
        } catch (error) { /* task 已 setStatus */ }
      }, 'btn-primary'));
      return panel;
    }

    const installCard = card('安装新扩展', true);
    view.appendChild(installCard);
    installCard.appendChild(node('div', 'runtime-warning',
      '安装前请确认来源可信。包内容 base64 编码并以 SHA-256 摘要锚定（digest-pinned），' +
      '篡改复检会拒绝不一致的包。安装即替换同 type 的旧版本（grant 不跨身份延续，需重新授权）。'));
    const form = node('div', 'runtime-form'); installCard.appendChild(form);
    const slotInput = input('挂载 slot', 'workbench.grid', {
      select: [
        { value: 'workbench.grid', label: 'workbench.grid（工作台主视图）' },
        { value: 'chat.sidebar', label: 'chat.sidebar（聊天侧栏）' },
        { value: 'diagnostics.context', label: 'diagnostics.context（诊断上下文栏）' },
      ],
    });
    form.append(slotInput.wrap);
    const manifestInput = input('Manifest JSON', '', {
      multiline: true, code: true,
      placeholder: '{"type":"acme.demo","version":"1.0.0","capabilities":["read:state"],"entry":{"kind":"esm","source":"https://example.com/w.js","sandbox":true}}',
    });
    manifestInput.control.rows = 8;
    form.append(manifestInput.wrap);
    const filesInput = input('Files JSON', '', {
      multiline: true, code: true,
      placeholder: '[{"path":"index.js","content_base64":"...","sha256":"..."}]',
    });
    filesInput.control.rows = 6;
    form.append(filesInput.wrap);
    form.appendChild(button('安装扩展', async () => {
      let manifest, files;
      try {
        manifest = parseJson(manifestInput.control.value, 'Manifest');
        files = parseJson(filesInput.control.value, 'Files');
      } catch (error) {
        setStatus(error.message, true);
        return;
      }
      // #488 W1：parseJson 只保证 JSON 合法，不保证形状。把非对象 manifest /
      // 非数组 files 提前拦在客户端，避免 confirm 提示里出现 undefined 类型名、
      // 也避免向 engine 发一个必然 400 的请求（传输层拒收无 error.code，
      // 客户端形状校验是第一道面）。
      if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) {
        setStatus('Manifest 必须是 JSON 对象（包含 type/version/entry 字段）', true);
        return;
      }
      if (!Array.isArray(files)) {
        setStatus('Files 必须是 JSON 数组（每个元素含 path/content_base64/sha256）', true);
        return;
      }
      if (!await AIRPConfirm.confirm('即将安装扩展 ' + (manifest.type || '?') + '。继续？', { title: '确认安装扩展', danger: false })) return;
      try {
        const body = { manifest: manifest, files: files, slot: slotInput.control.value };
        const resp = await task('安装扩展', () => client.request('POST', '/v1/extensions/install', body));
        setStatus('已安装：' + resp.type + '（digest=' + (resp.digest || '').slice(0, 12) + '…）');
        manifestInput.control.value = '';
        filesInput.control.value = '';
        loadList();
        loadGrantsOverview();
      } catch (error) { /* task 已 setStatus */ }
    }, 'btn-primary'));

    loadList();
  }

  async function renderUnavailable(kind) {
    const view = $('#view'); view.replaceChildren(); const box = card(kind === 'backup' ? '备份与恢复' : '插件管理', true); box.append(node('div', 'runtime-warning', kind === 'backup' ? '当前 Engine 没有备份/恢复 HTTP API。为避免制造“已备份”的假象，本页不提供不可验证的操作。请先通过文件系统或部署层备份 AIRP 数据目录。' : '当前 Engine 没有插件发现、安装或权限管理 API。本页只声明能力缺口，不伪造插件状态。'), node('p', 'runtime-muted', '后端提供正式契约后，可在此接入并加入 smoke 验收。')); view.appendChild(box);
  }

  // C-P1：等待 widget 引导模块（assets/widgets/boot.js）把就绪 Promise 挂到
  // window.__airpWidgetBoot；超时（模块未加载/被裁剪）返回 null 静默跳过。
  function waitForWidgetBoot(timeoutMs) {
    if (timeoutMs === undefined) timeoutMs = 5000;
    return new Promise(resolve => {
      if (window.__airpWidgetBoot) return resolve(window.__airpWidgetBoot);
      const started = Date.now();
      const timer = setInterval(() => {
        if (window.__airpWidgetBoot) { clearInterval(timer); resolve(window.__airpWidgetBoot); }
        else if (Date.now() - started > timeoutMs) { clearInterval(timer); resolve(null); }
      }, 50);
    });
  }

  async function boot() {
    renderChrome();
    $('#heading-title').textContent = titles[screen] || (screen === 'onboarding' ? '首次连接' : screen === 'backup' ? '备份与恢复' : screen === 'plugins' ? '插件管理' : screen === 'notes' ? '备注与连接' : 'AIRP 控制台');
    try {
      const health = await client.request('GET', '/health'); $('#engine-status').className = 'status-pill ok'; $('#engine-status').lastChild.textContent = health.provider_configured ? 'Engine 与 Provider 就绪' : 'Engine 就绪 · Provider 待配置';
      await loadScope();
      // CodeRabbit #8：屏 38–42 是独立 HTML 页面（各自加载 style-learn.js /
      // dialogue-gen.js / worldbook-graph.js / timeline-export.js / card-diff.js），
      // 不通过 console-runtime.js 渲染。但 nav 链接的 id（stylelearn 等）会出现在
      // ?screen= 查询参数里——若用户从书签或外部链接访问 console.html?screen=stylelearn，
      // 旧代码会落入 renderDiagnostics fallback 而非跳到正确的专用页面。
      // 这里加 redirect renderer，把这类请求转发到对应的 HTML 页面。
      const redirectRenderer = href => () => { location.href = pathWithState(href); };
      const renderers = { workbench: renderWorkbench, worldbook: renderWorldbook, presets: renderPresets, persona: renderPersona, agent: renderAgent, settings: renderSettings, memory: renderMemory, scenes: renderScenes, branches: renderBranches, preview: renderPreview, quota: renderQuota, diagnostics: renderDiagnostics, style: renderStyle, backup: renderBackup, plugins: renderPlugins, notes: renderNotes, onboarding: () => { location.href = '16-onboarding.html'; }, wizardmodel: () => { location.href = '16-onboarding.html'; }, stylelearn: redirectRenderer('38-style-learn.html'), dialoguegen: redirectRenderer('39-dialogue-gen.html'), wbgraph: redirectRenderer('40-worldbook-graph.html'), timeline: redirectRenderer('41-timeline-export.html'), carddiff: redirectRenderer('42-card-diff.html') };
      await (renderers[screen] || renderDiagnostics)();
      // C-P1 widget slots：屏渲染完成后挂载 [data-slot]。boot.js 是 module
      // 脚本（defer），晚于本经典脚本执行；它把挂载完成 Promise 赋给
      // window.__airpWidgetBoot，这里等它就绪后再拿 API 接线。
      const widgetBoot = await waitForWidgetBoot();
      if (widgetBoot) {
        try {
          const widgets = await widgetBoot;
          if (widgets) {
            widgets.setAuthFailureHandler(markAuthExpired);
            window.__airpSlotHandles = await widgets.bootWidgetSlots();
          }
        } catch (widgetError) {
          console.warn('[widgets] slot 挂载失败：', widgetError);
        }
      }
    } catch (error) {
      $('#engine-status').className = 'status-pill danger'; $('#engine-status').lastChild.textContent = '连接或加载失败'; setStatus(message(error), true);
      const view = $('#view'); if (!view.children.length) { const box = card('无法加载页面', true); box.appendChild(node('p', 'runtime-warning', message(error))); view.append(box, connectionCard()); }
    }
  }
  boot();
})();
